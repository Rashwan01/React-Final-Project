import React, { Component } from "react";

class Filter extends Component {
  render() {
    return (
      <div className="filter">
        <div style={{ paddingLeft: 1.5 + "rem", fontSize: 1.9 + "rem" }}>
          Latest Product
        </div>
      </div>
    );
  }
}
export default Filter;
